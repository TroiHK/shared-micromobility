<?php
/*
Template Name: Legal Notice
*/

get_header(); ?>

<section class="container-mentions">
	<article class="container-single">
	    <div class="">
	    	<h2 class="single-title">
	    		<?php the_title(); ?>
	    	</h2>
	    	<div class="single-text">
	            <?php the_content(); ?>
	        </div>
	    </div>   
	</article> 
</section>

<?php get_footer();