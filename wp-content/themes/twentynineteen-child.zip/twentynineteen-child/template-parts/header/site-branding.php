<?php
/**
 * Displays header site branding
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since 1.0.0
 */
?>

	<header class="container d-flex align-items-center no-padding">
		<div class="header-container">
			<span class="icon-menu">
	        </span>			

			<h1 class="title-site">
				BikeShareNews
			</h1>

			<span class="icon-search">
	        </span>	
	       </div>
	</header>