<form role="search" method="get" class="has-search">
	<input type="search" class="form-control" placeholder="Search" value="" name="s">
    <span class="icon-search-form"></span>
</form>

